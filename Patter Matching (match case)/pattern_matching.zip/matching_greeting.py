def welcome(user=""):
    match user:
        case "":
            return "hello anonymous"
        case name:
            return f"hello {name}"
        
print(welcome())
print(welcome("Pavel"))