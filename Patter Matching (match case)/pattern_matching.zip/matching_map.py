def config_parse(config, process_route, process_persistance):
   match config:
        case {"route" : route}:
           process_route(route)      
        case {"persistent" : "no"}:
           process_persistance()
        
        case {"persistent" : "yes", **rest}:
           process_persistance(rest) 
# start here

def process_route(route):
    print(f"route is {route}")
    
def process_persistance(source=""):
    print(f"persistance {source} called")
    
config_parse({"route":"127.0.0.1"},process_route,process_persistance)
config_parse({"route": "127.0.0.2","persistent" : "no"},process_route,process_persistance)
config_parse({"persistent" : "no","route": "127.0.0.3"},process_route,process_persistance)
config_parse({"persistent" : "no"},process_route,process_persistance)
config_parse({"persistent": "yes","test" : 2, "warn" : "off"},process_route,process_persistance)
config_parse({"persistent" : "yes"}, process_route,process_persistance)