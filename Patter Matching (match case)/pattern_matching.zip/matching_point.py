def get_point_info(pt):
    match pt:
        case (0,0):
            return "center"
        case (0,y):
            return f"point on Y axis with coord 0,{y}"
        case (x,0):
            return f"point on X axis with coord {x},0"
        case (10,_):
            return f"point on X axies with unknown Y coord 8-)"
        case (x,y) if type(x) == int and type(y) == int:
        # case (x,y):
        #     if type(x) == int and type(y) == int:
                return f"Point with coord {x},{y}"
            # else:
            #     return "bad coord type"
        case  _:
            return "Is not point!"

print(get_point_info((1,2)))
print(get_point_info((0,0)))
print(get_point_info((1,0)))
print(get_point_info((0,1)))
print(get_point_info(1))

print(get_point_info((1,2,3)))
print(get_point_info(("a","b")))

print(get_point_info((10,1000)))
print(get_point_info((10,0)))