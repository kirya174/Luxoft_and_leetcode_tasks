def get_info_collection(source):
    match source:
        case 1,[x,*other]:
            return f"Got 1, next {x} and {other}"
        case (1,x):
            return f"Got 1 and {x}"
        case _:
            return "unknown collection"
    
print(get_info_collection([2,[2,4,5]]))
print(get_info_collection((1,2)))
print(get_info_collection([1,[3,4,5]]))